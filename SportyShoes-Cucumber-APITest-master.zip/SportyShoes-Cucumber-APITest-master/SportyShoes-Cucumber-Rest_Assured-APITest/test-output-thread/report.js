$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"89048d81-3e08-4f7f-b478-1fdce0b01771","feature":"End to End Test for SportyShoes API","scenario":"API ables to Get all products,Add,Update,Delete products and Get all registered users","start":1699940993923,"group":1,"content":"","tags":"","end":1699940997470,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});