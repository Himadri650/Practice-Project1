$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"fb722846-058d-4c87-bc4a-c50b817d0ec8","feature":"End to End Test for Medicare API","scenario":"API ables to Get all products,Add,Update,Delete products and Get all registered users","start":1700040453586,"group":1,"content":"","tags":"","end":1700040456720,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});