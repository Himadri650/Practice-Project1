$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"fc412c41-ec44-4df3-a35d-c6e21a182c92","feature":"Test the starHealth page on Chrome Browser","scenario":"Validate the Star Health Buy Now flow","start":1698033520983,"group":1,"content":"","tags":"","end":1698033597442,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});