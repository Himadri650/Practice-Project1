$(document).ready(function() {
CucumberHTML.timelineItems.pushArray([{"id":"3fbafdfb-97e5-4c80-b6ee-a2d568f1ffca","feature":"Testing Amazon Page","scenario":"User has to test if the product is add to wishlist successfuly or not","start":1698063236424,"group":1,"content":"","tags":"","end":1698063372193,"className":"passed"}]);
CucumberHTML.timelineGroups.pushArray([{"id":1,"content":"Thread[main,5,main]"}]);
});