package org.junit.jupiter.params.converter;

public class AnnotationBasedArgumentConverter {

}
