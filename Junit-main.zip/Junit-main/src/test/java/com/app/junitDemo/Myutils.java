package com.app.junitDemo;

import java.util.function.BooleanSupplier;

public class Myutils {

	public static BooleanSupplier isPalindrome(String inputText) {
		// TODO Auto-generated method stub
		return null;
	}

}
